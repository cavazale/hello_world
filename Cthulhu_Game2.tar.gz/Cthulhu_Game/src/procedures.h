/**
 * @file
 * file header contenente i prototipi delle funzioni di implementazione del programma
 */

#include <iostream>

using namespace std;

#define ScreenWidth 700   /**< Larghezza display */
#define ScreenHeight 900  /**< Altezza display */

/**
 *  Funzione di disegno del menu di gioco.
 *  
 *  Utilizza la funzione al_flip_display che copia e aggiorna i front e back buffer in 
 *  modo tale che ciò che è stato disegnato precedentemente diventi visibile sul display
 *  
 *  @param[in] font puntatore di tipo ALLEGRO_FONT per il font del titolo del gioco
 *  @param[in] font2 puntatore per il font delle altre scritte del menu di gioco
 *  @param[in] cthulhu puntatore di tipo ALLEGRO_BITMAP al player per la selezione di
 *		start o exit
 *  @param[in] x coordinata del player di selezione
 *  @param[in] y coordinata del player di selezione
 */
void draw(ALLEGRO_FONT, ALLEGRO_FONT, ALLEGRO_BITMAP, int, int);



/**
 * Caricamento del file di testo “bestscore.txt”.
 *
 * @param[in] bestscore vedi ::bestscore
 * @return Vero se il caricamento dal file è andato a buon fine
 */
bool carica_file(int &);



#define Min 1.5                /**< altezza minima a cui può arrivare il player prima di perdere la partita */
#define Max ScreenHeight-70    /**< altezza massima a cui può arrivare il player prima di perdre la partita */
#define FPS 60                /**< variabile utilizzata per settare la velocità del timer */

#define MonetaSu 150                   /**< altezza della moneta quando si trova nella parte alta del display */
#define MonetaGiu ScreenHeight-150     /**< altezza della moneta quando si trova nella parte bassa del display */

/**
 * Funzione che crea il mostro i-esimo da far apparire sul display.
 * 
 * Altezza e velocità del mostro i-esimo sono casuali (implementate attraverso rand
 * @param[in] mon mostro i-esimo di tipo struct monster_t
 * @param[in] i contatore che indica quale mostro viene creato
 */
void crea_mostro(monster_t mon[], int &);



/**
 * Funzione che controlla se è avvenuta la collisione mostro-player.
 * 
 * Controllo se è avvenuta una collisione tra il player e il mostro, in tal caso richiamo ::game_over,
 * altrimenti richiama ::crea_mostro.
 * @param[in] cont variabile di tipo intero locale alla funzione game,
 *		   che aumenta ad ogni clock del timer in modo tale che,quando il suo valore è maggiore 
 * 		   o uguale a 25 (controllo della funzione ::collisions) appare un nuovo mostro sul display 
 * 		   e uno già presente che è giunto alla fine del display viene disattivato
 * @param[in] mon  monstro di cui controllo la collisione con il player di tipo struct monster_t
 * @param[in] c player di tipo struct cthulhu_t
 * @param[in] score variabile di tipo int, locale alla funzione game che memorizza il punteggio ottenuto 
 *		    dal player nella partita (ogni volta che avviene una collisione 
 *		    con una moneta il punteggio aumenta di dieci)
 * @return Falso se avviene la collisione con il player
 * @return Vero se non è avvenuta alcuna collisione
 */
bool collisions(int &, monster_t mon[], cthulhu_t &c, int &);



/**
 * Funzione che crea la moneta in alto o in basso a seconda di dove sia avvenuta la collisione con il player,
 * oppositamente ad esso.
 * 
 * Se avviene la collisione con il player lo score aumenta
 * @param[in] m moneta di tipo struct moneta_t di cui si controlla il posizionamento e la collisione con il player
 * @param[in] c player di tipo struct cthulhu_t
 * @param[in] score variabile di tipo int, locale alla funzione game che memorizza il punteggio ottenuto 
 *		    dal player nella partita (ogni volta che avviene una collisione 
 *		    con una moneta il punteggio aumenta di dieci)
 */
void crea_moneta (moneta_t &m, cthulhu_t &c, int&);



/**
 * Funzione che disegna la schermata di game over.
 * 
 * Sul display viene mostrato lo score corrente e il bestscore. Si può accedere nuovamente al menu di gioco
 * premendo esc.
 * @param[in] score variabile di tipo int, locale alla funzione game che memorizza il punteggio ottenuto 
 *		    dal player nella partita (ogni volta che avviene una collisione 
 *		    con una moneta il punteggio aumenta di dieci)
 */
void game_over(int&);



/**
 * Seconda funzione di disegno del display di gioco.
 * 
 * Implementata in modo simile a ::draw con la differenza della presenza di un ciclo for per il disegno dei mostri
 * sul display.
 * @param[in] m moneta
 * @param[in] c player
 * @param[in] mon mostro i-esimo
 * @param[in] sfondo puntatore di tipo ALLEGRO_BITMAP per il caricamento del bitmap utilizzato come sfondo nel gioco
 * @param[in] font_score puntatore di tipo ALLEGRO_FONT per la scritta in alto a destra dello score
 * @param[in] score variabile di tipo int, locale alla funzione game che memorizza il punteggio ottenuto 
 *		    dal player nella partita (ogni volta che avviene una collisione 
 *		    con una moneta il punteggio aumenta di dieci)
 */
void draw2(moneta_t &m, cthulhu_t &c, monster_t mon[], ALLEGRO_BITMAP, ALLEGRO_BITMAP, ALLEGRO_FONT, int);



/**
 * Funzione di inizializzazione.
 * inizializzazione della moneta, del player e dei mostri(ad inizio partita sul display non ve ne sono),
 * @param[in] m moneta
 * @param[in] c player
 * @param[in] mon mostro i-esimo
 */
void initialize(moneta_t &m, cthulhu_t &c, monster_t mon[]);



/**
 * Funzione che distrugge il puntatore timer e la coda di eventi event_queue1
 * 
 * @param[in] fine bool
 * @param[in] timer
 * @param[in] event_queue1
 */
void distruggi(bool, ALLEGRO_EVENT_QUEUE, ALLEGRO_TIMER);


/**
 * Funzione che implementa il gioco vero e proprio.
 * 
 * Vengono richiamate ::draw2, ::collisions, ::crea_moneta, ::game_over.
 * Inizialmente vengono definite le struct moneta e mostro, la variabile score e cont, e vengono effettuati i
 * controlli sui movimenti del player
 * @param[in] c player
 */
void game (cthulhu_t &c);



/**
 * Salvataggio del valore di bestscore nel file di testo "bestscore.txt".
 * 
 * @param[in] n valore da salvare nel file
 * @return Vero se il salvataggio di bestscore nel file di testo è andato a buon fine
 */
bool salva_file(const int &);



/**
 * Funzione di controllo del bestscore.
 * 
 * Controlla lo score attuale e lo confronta con il bestscore salvato e se maggiore di quest'ultimo aggiorna
 * la variabile bestscore con il valore di score
 * @param[in] score variabile di tipo int, locale alla funzione game che memorizza il punteggio ottenuto 
 *		    dal player nella partita (ogni volta che avviene una collisione 
 *		    con una moneta il punteggio aumenta di dieci)
 * @param[in] bestscore  ::bestscore
 */
void trova_massimo(int &);
