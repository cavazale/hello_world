var searchData=
[
  ['y',['y',['../structcthulhu__t.html#a65e4b05377d3ab8f4b08f4b6734b446b',1,'cthulhu_t::y()'],['../structmonster__t.html#ab3c7814fee2e8829f709184aa195e59c',1,'monster_t::y()']]]
];
