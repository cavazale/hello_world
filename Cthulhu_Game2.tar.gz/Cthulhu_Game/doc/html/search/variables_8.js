var searchData=
[
  ['up',['UP',['../structmoneta__t.html#a888e3f94afb32b5ebe783b4a855ae08d',1,'moneta_t']]]
];
