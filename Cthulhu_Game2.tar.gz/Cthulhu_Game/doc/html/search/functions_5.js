var searchData=
[
  ['salva_5ffile',['salva_file',['../cthulhu_8cc.html#ae5d1c1f61003ad310381abc84145277e',1,'salva_file(const int &amp;n):&#160;cthulhu.cc'],['../procedure_8h.html#a2398f78ca25f2b0b6c3ed6908d455dfa',1,'salva_file(const int &amp;):&#160;cthulhu.cc']]]
];
