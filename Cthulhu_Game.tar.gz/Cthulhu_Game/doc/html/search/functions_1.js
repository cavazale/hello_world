var searchData=
[
  ['draw',['draw',['../cthulhu__game_8cc.html#a5d4a6684b846ae50d6f0f141df41058c',1,'draw(ALLEGRO_FONT *font, ALLEGRO_FONT *font2, ALLEGRO_BITMAP *cthulhu, int x, int y):&#160;cthulhu_game.cc'],['../procedure_8h.html#a1487f17c9a2d11f6ebc104f1efcc1a13',1,'draw(ALLEGRO_FONT, ALLEGRO_FONT, ALLEGRO_BITMAP, int, int):&#160;procedure.h']]],
  ['draw2',['draw2',['../cthulhu_8cc.html#a7aebf4704e862e34c6a98694f283ec3a',1,'draw2(moneta_t &amp;m, cthulhu_t &amp;c, monster_t mon[], ALLEGRO_BITMAP *monster, ALLEGRO_BITMAP *sfondo, ALLEGRO_FONT *font_score, int score):&#160;cthulhu.cc'],['../procedure_8h.html#ab1825a490ea896091e0f093c7d97ab99',1,'draw2(moneta_t &amp;m, cthulhu_t &amp;c, monster_t mon[], ALLEGRO_BITMAP, ALLEGRO_BITMAP, ALLEGRO_FONT, int):&#160;procedure.h']]]
];
