var searchData=
[
  ['larghezza',['larghezza',['../structmonster__t.html#a1ad50d0a2506eadb1ce41881d1935f9c',1,'monster_t']]]
];
