var searchData=
[
  ['screenheight',['ScreenHeight',['../cthulhu_8h.html#afb3d6d52c621e78b7e630900bd8b8a85',1,'ScreenHeight():&#160;cthulhu.h'],['../cthulhu__game_8cc.html#afb3d6d52c621e78b7e630900bd8b8a85',1,'ScreenHeight():&#160;cthulhu_game.cc'],['../procedure_8h.html#afb3d6d52c621e78b7e630900bd8b8a85',1,'ScreenHeight():&#160;procedure.h']]],
  ['screenwidth',['ScreenWidth',['../cthulhu_8h.html#a097f7a7fc632adc5aed06029a23ee792',1,'ScreenWidth():&#160;cthulhu.h'],['../cthulhu__game_8cc.html#a097f7a7fc632adc5aed06029a23ee792',1,'ScreenWidth():&#160;cthulhu_game.cc'],['../procedure_8h.html#a097f7a7fc632adc5aed06029a23ee792',1,'ScreenWidth():&#160;procedure.h']]]
];
