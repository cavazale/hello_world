var searchData=
[
  ['bestscore',['bestscore',['../cthulhu_8cc.html#a2dea68cb17b9cb6293bb0c0b07607e27',1,'bestscore():&#160;cthulhu.cc'],['../cthulhu__game_8cc.html#a2dea68cb17b9cb6293bb0c0b07607e27',1,'bestscore():&#160;cthulhu.cc']]]
];
