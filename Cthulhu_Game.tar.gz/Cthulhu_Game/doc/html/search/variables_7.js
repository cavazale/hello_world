var searchData=
[
  ['speed',['speed',['../structcthulhu__t.html#a7ead571f9eecb9f957cb74b45d87bbed',1,'cthulhu_t']]],
  ['speed_5fmonster',['speed_monster',['../structmonster__t.html#af64e19c967c2f5ea303610d2ada0a1e7',1,'monster_t']]]
];
