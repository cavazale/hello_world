var searchData=
[
  ['x',['x',['../structcthulhu__t.html#ad4f2638854d4494e16bd85c24d517028',1,'cthulhu_t::x()'],['../structmonster__t.html#a184470b6b3c8106ecce34c8210fe5393',1,'monster_t::x()']]]
];
