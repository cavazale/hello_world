/**
 *  @file
 *  
 *  File contenente il main del programma
 *
 *  @author Alessia Cavazza	
*/

/**
 *  @file 
 *  Cthulhu_Game
 *  @mainpage cthulhu_game
 * 
 *  Gioco ispirato all’applicazione Cthulhu Virtual Pet. Il player deve
 *  destreggiarsi tra i mostri che giungono casualmente dalla destra del
 *  display per poter recuperare le monete che appaiono in alto e in basso
 *  rispetto ad esso, totalizzando il miglior punteggio. Se un si scontra 
 *  con un mostro il player perde automaticamente la partita.
 *  
 *  Vedere la documentazione della funzione ::game per maggiori dettagli
 *  sul funzionamento del gioco.
 */

#include <iostream>
#include <stdio.h>
#include <fstream>
#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_audio.h>
#include <allegro5/allegro_acodec.h>
#include "structures.h"
#include "procedures.h"

using namespace std;

#define ScreenWidth 700    /**< Larghezza display */
#define ScreenHeight 900   /**< Altezza display */

extern int bestscore;      /**< Variabile in cui viene memorizzato il best score 
			    *   di tipo extern poiché viene definita nel file cthulhu.cc
			    */

/**
 *  Funzione ::carica_file
 */
bool carica_file(int &bestscore){
  ifstream f("bestscore.txt");
  if (!f)
    return false;
  int n;
  f>>n;
  bestscore = n;
  f>>bestscore;
  return f;
}


/**
 *  Funzione ::draw
 */
void draw (ALLEGRO_FONT *font, ALLEGRO_FONT *font2, ALLEGRO_BITMAP *cthulhu, int x, int y){
  al_clear_to_color(al_map_rgb(0,50, 40));
  al_draw_text(font, al_map_rgb(0, 70, 60), ScreenWidth/2, (ScreenHeight/6),ALLEGRO_ALIGN_CENTRE, "Cthulhu Game");
  
  al_draw_textf(font2, al_map_rgb(0, 70, 70), ScreenWidth/2, ScreenHeight/2.7, ALLEGRO_ALIGN_CENTRE, "BESTSCORE: %d", bestscore);
  al_draw_text(font2, al_map_rgb(0,70, 60), ScreenWidth/2, (ScreenHeight/2), ALLEGRO_ALIGN_CENTRE, "Start Game");
  al_draw_text(font2, al_map_rgb(0,70,60), ScreenWidth/2, (ScreenHeight/1.7), ALLEGRO_ALIGN_CENTRE, "Exit");
  al_draw_bitmap(cthulhu, x, y, 0);
  al_convert_mask_to_alpha(cthulhu, al_map_rgb(255, 255,255));
  al_flip_display();
}

/**
 *  Funzione main
 *
 *  Nella funzione principale viene implementato il menu con l'utilizzo di funzioni di allegro.
 *  Viene effettuata la chiamata di ::draw e di ::game.
 */
int main(int argc, char **argv){

  cthulhu_t c;
  ALLEGRO_DISPLAY *display = NULL;
  ALLEGRO_SAMPLE *soundEffect = NULL;

  if (!al_init()){
    cout<<"Failed to initialize allegro!"<<endl;
    return -1;
  }
    
  al_install_audio();
  
  al_init_font_addon();
  al_init_ttf_addon();
  al_init_image_addon();
  al_init_acodec_addon();

  display = al_create_display(ScreenWidth, ScreenHeight);

  if (!display){
    cout<<"Failed to create display"<<endl;
    return -1;
  }
    
  ALLEGRO_FONT *font = al_load_ttf_font ("media/horror.ttf", 80, 0);
  ALLEGRO_FONT *font2 = al_load_ttf_font ("media/horror.ttf", 50, 0);
  ALLEGRO_BITMAP *cthulhu = al_load_bitmap("media/cthulhu3.bmp");
  al_convert_mask_to_alpha(cthulhu, al_map_rgb(255, 255,255));
    
  if (!font || !font2){
    cout<<"Could not load horror.ttf"<<endl;
    return -1;
  }
    
  al_install_keyboard();
  
  ALLEGRO_EVENT_QUEUE *event_queue = al_create_event_queue();
  //al_reserve_samples(1);
  soundEffect = al_load_sample("media/sound.wav");
  al_register_event_source(event_queue, al_get_display_event_source(display));
  bool done = false;
  const int x = ScreenWidth/5;
  float y = ScreenHeight/2.0;
  bool dir_su = true;
  carica_file(bestscore);
  draw (font, font2, cthulhu, x, y);
  while(!done){
    ALLEGRO_EVENT events;
    al_register_event_source(event_queue, al_get_keyboard_event_source());
    al_wait_for_event(event_queue, &events);
    
    if (events.type == ALLEGRO_EVENT_KEY_DOWN){
      switch (events.keyboard.keycode){
	case ALLEGRO_KEY_DOWN:{
	  if(dir_su == true){
	    dir_su = false;
	    y += 80.0;
	    al_play_sample(soundEffect, 1.0, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
	    break;
	  }else
	    break;}
	case ALLEGRO_KEY_UP:{
	  al_play_sample(soundEffect, 1.0, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, 0);
	  if(dir_su == false){
	    dir_su = true;
	    y -= 80.0;
	    break;
	  }else
	    break;}
	case ALLEGRO_KEY_ENTER:{
	  al_play_sample(soundEffect, 1.0, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, 0);
	  if(dir_su == false)
	    done = true;
	  
	  if (dir_su == true){
	    al_destroy_event_queue(event_queue);
	    game(c);
	    event_queue = al_create_event_queue();
	  }
	  break;}
	case ALLEGRO_KEY_ESCAPE:{
	  al_play_sample(soundEffect, 1.0, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, 0);
	  done = true;
	  break;}
      }
    }
    draw(font, font2, cthulhu, x,y);

  }
    
  al_destroy_display(display);
  al_destroy_bitmap(cthulhu);
  al_destroy_sample(soundEffect);
  al_destroy_event_queue(event_queue);

  return 0;
}
